import { PageHeader, Panel, SampleNotice } from "@/components/bioscan/parts";

const ROWS = [
  {
    observation: "Chlorophyll-a increase",
    biological: "Phytoplankton growth",
    alternatives: "Nutrient availability, sea ice changes",
    check: "Chlorophyll-a trend, sea ice extent, SST",
  },
  {
    observation: "Chlorophyll-a decrease",
    biological: "Possible viral lysis",
    alternatives: "Zooplankton grazing, nutrient limitation",
    check: "Chlorophyll-a trend, sea ice extent, nutrient data where available",
  },
  {
    observation: "SO₂ increase",
    biological: "No direct viral attribution",
    alternatives: "Volcanic emissions, atmospheric transport",
    check: "OMI SO₂ column, wind transport, volcanic activity records",
  },
  {
    observation: "NO₂ increase",
    biological: "No direct viral attribution",
    alternatives: "Atmospheric transport, combustion emissions",
    check: "OMI NO₂ column, wind transport",
  },
  {
    observation: "Sea ice reduction",
    biological: "Changes in microbial habitats",
    alternatives: "Atmospheric warming, ocean warming",
    check: "NSIDC sea ice extent, AIRS temperature, MODIS SST",
  },
  {
    observation: "Possible DMS increase",
    biological: "Viral host-cell lysis",
    alternatives: "Phytoplankton metabolism, bacterial activity",
    check: "No direct DMS satellite measurement; use in situ DMS data",
  },
];

export default function AlternativeCausesRoute() {
  return (
    <div className="flex min-h-full flex-col">
      <PageHeader title="Alternative Causes" subtitle="Every unusual observation is paired with explanations that do not involve viruses." />
      <div className="space-y-5 p-6">
        <SampleNotice />
        <Panel title="Observation analysis">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[760px] text-left text-sm">
              <thead className="text-xs uppercase tracking-wider text-muted-foreground">
                <tr className="border-b border-border">
                  <th className="py-2 pr-4 font-medium">Observation</th>
                  <th className="py-2 pr-4 font-medium">Possible biological cause</th>
                  <th className="py-2 pr-4 font-medium">Alternative explanations</th>
                  <th className="py-2 font-medium">Satellite evidence to check</th>
                </tr>
              </thead>
              <tbody>
                {ROWS.map((r) => (
                  <tr key={r.observation} className="border-b border-border/60 align-top">
                    <td className="py-3 pr-4 font-medium">{r.observation}</td>
                    <td className="py-3 pr-4 text-muted-foreground">{r.biological}</td>
                    <td className="py-3 pr-4 text-muted-foreground">{r.alternatives}</td>
                    <td className="py-3 text-muted-foreground">{r.check}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>
        <p className="text-xs text-muted-foreground">
          Environmental changes are not attributed to viruses automatically. A viral explanation is only considered after the alternatives above are checked.
        </p>
      </div>
    </div>
  );
}
