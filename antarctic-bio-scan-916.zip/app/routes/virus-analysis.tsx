import { PageHeader, Panel, SampleNotice } from "@/components/bioscan/parts";
import { VIRUS_CATALOG, type VirusRelation } from "@/lib/bioscan/data";

const GROUPS: { evidence: VirusRelation["evidence"]; heading: string; description: string }[] = [
  {
    evidence: "Cultured and characterized",
    heading: "Confirmed in culture",
    description: "Virus-host pairs characterized in laboratory studies. This does not mean the virus was detected from satellites.",
  },
  {
    evidence: "Environmental detection reported",
    heading: "Environmental detections reported",
    description: "Viruses reported from field samples. Antarctic-specific pairs still need verification.",
  },
  {
    evidence: "Potential relationship (inferred)",
    heading: "Potential relationships",
    description: "Host-virus links inferred from ecology. Treat as hypotheses to test.",
  },
];

const CHAIN = [
  "Chlorophyll-a rises in satellite data",
  "Phytoplankton growth is investigated",
  "Candidate hosts are identified (e.g., Phaeocystis antarctica, diatoms)",
  "Documented viruses for those hosts are listed",
  "Alternative causes are tested before any viral attribution",
];

export default function VirusAnalysisRoute() {
  return (
    <div className="flex min-h-full flex-col">
      <PageHeader title="Virus & Microbe Analysis" subtitle="Documented virus-host relationships, separated from satellite observations." />
      <div className="space-y-5 p-6">
        <SampleNotice />
        <Panel title="How the analysis works">
          <ol className="grid gap-2 md:grid-cols-5">
            {CHAIN.map((step, i) => (
              <li key={step} className="rounded-lg border border-border bg-background/40 p-3 text-xs text-muted-foreground">
                <span className="mb-1 block font-semibold text-primary">Step {i + 1}</span>
                {step}
              </li>
            ))}
          </ol>
          <p className="mt-3 text-xs text-muted-foreground">
            Satellite imagery cannot detect viruses. Chlorophyll-a, SO₂, NO₂ and temperature do not confirm virus presence.
          </p>
        </Panel>
        {GROUPS.map((group) => (
          <Panel key={group.evidence} title={group.heading}>
            <p className="mb-3 text-xs text-muted-foreground">{group.description}</p>
            <div className="grid gap-3 md:grid-cols-2">
              {VIRUS_CATALOG.filter((v) => v.evidence === group.evidence).map((v) => (
                <div key={v.virus} className="rounded-lg border border-border p-3">
                  <p className="text-sm font-medium">{v.virus}</p>
                  <p className="mt-1 text-xs text-muted-foreground">Family: {v.family}</p>
                  <p className="text-xs text-muted-foreground">Host: {v.host}</p>
                  <p className="mt-2 text-xs text-muted-foreground">{v.antarcticNote}</p>
                </div>
              ))}
            </div>
          </Panel>
        ))}
        <Panel title="Environmental conditions that may support hosts">
          <ul className="list-inside list-disc space-y-1 text-sm text-muted-foreground">
            <li>Open water with light, following sea ice retreat</li>
            <li>Surface temperatures within the tolerance range of each candidate host (to be verified per species)</li>
            <li>Nutrient supply from upwelling or meltwater (to be verified per region)</li>
          </ul>
        </Panel>
      </div>
    </div>
  );
}
