import { PageHeader, Panel, SampleNotice } from "@/components/bioscan/parts";

const MECHANISMS = [
  {
    title: "A. Viral activity",
    items: ["Viral infection of phytoplankton", "Host cell lysis", "Release of DMSP", "Possible conversion of DMSP into DMS"],
  },
  {
    title: "B. Phytoplankton activity",
    items: ["Increased phytoplankton populations", "DMSP production by certain phytoplankton groups", "Biological sulfur cycling"],
  },
  {
    title: "C. Bacterial activity",
    items: ["Bacterial conversion of DMSP into DMS", "Microbial sulfur metabolism"],
  },
  {
    title: "D. Volcanic activity",
    items: ["Volcanic sulfur emissions", "Possible atmospheric SO₂ increases", "Volcanic influence on regional atmospheric chemistry"],
  },
  {
    title: "E. Other environmental factors",
    items: ["Sea ice melting", "Ocean temperature changes", "Atmospheric transport", "Seasonal biological activity"],
  },
];

export default function DmsSulfurRoute() {
  return (
    <div className="flex min-h-full flex-col">
      <PageHeader title="DMS & Sulfur Cycle" subtitle="Possible biological and environmental sources of dimethyl sulfide (DMS)." />
      <div className="space-y-5 p-6">
        <SampleNotice />
        <div className="grid gap-3 rounded-xl border border-bio-so2/40 bg-bio-so2/10 p-4 text-sm md:grid-cols-2">
          <p>
            <span className="font-semibold text-bio-so2">SO₂ is not DMS.</span> SO₂ is measured by OMI. It is a different compound and is not a direct DMS measurement.
          </p>
          <p>
            <span className="font-semibold text-foreground">Direct DMS unavailable.</span> The selected NASA instruments do not measure DMS concentration. Satellite SO₂ and NO₂ serve only as indirect indicators.
          </p>
        </div>
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {MECHANISMS.map((m) => (
            <Panel key={m.title} title={m.title}>
              <ul className="list-inside list-disc space-y-1 text-sm text-muted-foreground">
                {m.items.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </Panel>
          ))}
        </div>
        <Panel title="Alternative explanations for each observation">
          <p className="text-sm text-muted-foreground">
            Any DMS-related signal must be compared against the alternatives listed on the Alternative Causes page before it is linked to viral activity.
          </p>
        </Panel>
      </div>
    </div>
  );
}
