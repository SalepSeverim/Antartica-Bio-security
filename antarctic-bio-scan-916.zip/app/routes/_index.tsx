import {
  IconAtom,
  IconCloudFog,
  IconCircleCheck,
  IconLeaf,
  IconSnowflake,
  IconTemperature,
} from "@tabler/icons-react";
import { Link } from "react-router";

import { Button } from "@/components/ui/button";
import { PageHeader, Panel, SampleNotice, StatCard } from "@/components/bioscan/parts";
import { TimeSeriesCard } from "@/components/bioscan/TimeSeriesCard";
import { gibsSnapshotUrl } from "@/lib/bioscan/polar";

const KPIS = [
  { label: "Chlorophyll-a", value: "2.8", unit: "mg/m³", cssVar: "bio-chlorophyll", icon: <IconLeaf size={18} />, trend: "Reference sample" },
  { label: "Sea surface temp", value: "-1.2", unit: "°C", cssVar: "bio-sst", icon: <IconTemperature size={18} />, trend: "Reference sample" },
  { label: "Sea ice", value: "82", unit: "%", cssVar: "bio-ice", icon: <IconSnowflake size={18} />, trend: "Reference sample" },
  { label: "SO₂ column", value: "0.18", unit: "DU", cssVar: "bio-so2", icon: <IconCloudFog size={18} />, trend: "Reference sample" },
  { label: "NO₂ column", value: "0.27", unit: "10¹⁵ molec/cm²", cssVar: "bio-no2", icon: <IconAtom size={18} />, trend: "Reference sample" },
];

const THUMBNAIL = gibsSnapshotUrl({
  layer: "MODIS_Terra_CorrectedReflectance_TrueColor",
  date: "2025-01-15",
  size: 600,
  format: "image/jpeg",
});

export default function HomeRoute() {
  return (
    <div className="flex min-h-full flex-col">
      <PageHeader title="Antarctic Bio-Scan" subtitle="Satellite observations, documented virus-host relationships and alternative explanations for Antarctic microbial conditions.">
        <Button asChild variant="outline" size="sm">
          <Link to="/map">Open Antarctic map</Link>
        </Button>
      </PageHeader>

      <div className="space-y-5 p-6">
        <SampleNotice />

        <div className="grid grid-cols-2 gap-3 xl:grid-cols-5">
          {KPIS.map((k) => (
            <StatCard key={k.label} {...k} />
          ))}
        </div>

        <div className="grid gap-5 xl:grid-cols-[1.4fr_1fr]">
          <Panel title="Antarctica · MODIS Terra true-color (NASA GIBS)" className="p-3">
            <Link to="/map" className="group relative block overflow-hidden rounded-lg">
              <img src={THUMBNAIL} alt="NASA true-color satellite view of Antarctica" className="aspect-square w-full bg-[#02060f] object-cover transition-transform duration-300 group-hover:scale-[1.02]" />
              <span className="absolute bottom-3 right-3 rounded-md bg-background/80 px-2.5 py-1 text-xs text-foreground backdrop-blur">
                Open interactive map →
              </span>
            </Link>
          </Panel>

          <div className="flex flex-col gap-5">
            <Panel title="Scientific interpretation">
              <div className="space-y-3 text-sm leading-relaxed text-muted-foreground">
                <p>
                  Elevated chlorophyll-a can indicate phytoplankton growth. <span className="text-foreground">Phaeocystis</span> and diatoms are the main candidate hosts in Southern Ocean blooms.
                </p>
                <p>
                  Viruses that infect these hosts are documented in culture, but satellites cannot detect viruses. Sea ice loss or ocean warming may also explain the same pattern.
                </p>
              </div>
            </Panel>
            <Panel title="Result">
              <div className="flex items-start gap-3">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-bio-chlorophyll/15 text-bio-chlorophyll">
                  <IconCircleCheck size={18} />
                </div>
                <div className="space-y-3">
                  <p className="text-sm text-muted-foreground">
                    Sample values point to areas worth targeted field sampling. Virus presence must be confirmed by culture or sequencing.
                  </p>
                  <Button asChild size="sm" variant="secondary">
                    <Link to="/virus-analysis">View virus-host analysis</Link>
                  </Button>
                </div>
              </div>
            </Panel>
          </div>
        </div>

        <TimeSeriesCard />
      </div>
    </div>
  );
}
