import { useState } from "react";

import { AntarcticMap, type SelectedPoint } from "@/components/bioscan/AntarcticMap";
import { PageHeader, Panel, SampleNotice, SampleTag } from "@/components/bioscan/parts";
import { TimeSeriesCard } from "@/components/bioscan/TimeSeriesCard";
import {
  interpretLocation,
  LAYERS,
  LAYERS_BY_ID,
  SEASONS,
  sampleValue,
  YEARS,
  type LayerId,
  type SeasonId,
} from "@/lib/bioscan/data";

const SELECT_CLASS =
  "h-9 rounded-md border border-input bg-card px-2.5 text-sm text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring";

function latitudeBand(lat: number) {
  if (lat > -60) return "Sub-Antarctic margin";
  if (lat > -78) return "Coastal and ice-edge band";
  return "Continental interior band";
}

export default function MapRoute() {
  const [layerId, setLayerId] = useState<LayerId>("chlorophyll");
  const [year, setYear] = useState<number>(YEARS[YEARS.length - 1]);
  const [seasonId, setSeasonId] = useState<SeasonId>("summer");
  const [selected, setSelected] = useState<SelectedPoint | null>(null);

  const seasonIndex = SEASONS.findIndex((s) => s.id === seasonId);
  const values = selected
    ? {
        chlorophyll: sampleValue("chlorophyll", selected.lat, selected.lon, year, seasonIndex),
        oceanColor: sampleValue("oceanColor", selected.lat, selected.lon, year, seasonIndex),
        sst: sampleValue("sst", selected.lat, selected.lon, year, seasonIndex),
        atmTemp: sampleValue("atmTemp", selected.lat, selected.lon, year, seasonIndex),
        so2: sampleValue("so2", selected.lat, selected.lon, year, seasonIndex),
        no2: sampleValue("no2", selected.lat, selected.lon, year, seasonIndex),
        seaIce: sampleValue("seaIce", selected.lat, selected.lon, year, seasonIndex),
      }
    : null;
  const interpretation = values
    ? interpretLocation({ chlorophyll: values.chlorophyll, seaIce: values.seaIce, so2: values.so2, no2: values.no2 })
    : null;

  return (
    <div className="flex min-h-full flex-col">
      <PageHeader title="Antarctic Map" subtitle="Select a coordinate to generate a regional analysis for the chosen year and season.">
        <select aria-label="Layer" className={SELECT_CLASS} value={layerId} onChange={(e) => setLayerId(e.target.value as LayerId)}>
          {LAYERS.map((l) => (
            <option key={l.id} value={l.id}>
              {l.label}
            </option>
          ))}
        </select>
        <select aria-label="Year" className={SELECT_CLASS} value={year} onChange={(e) => setYear(Number(e.target.value))}>
          {YEARS.map((y) => (
            <option key={y} value={y}>
              {y}
            </option>
          ))}
        </select>
        <select aria-label="Season" className={SELECT_CLASS} value={seasonId} onChange={(e) => setSeasonId(e.target.value as SeasonId)}>
          {SEASONS.map((s) => (
            <option key={s.id} value={s.id}>
              {s.label}
            </option>
          ))}
        </select>
      </PageHeader>

      <div className="space-y-5 p-6">
        <SampleNotice />

        <div className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_420px]">
          <Panel title="Satellite map" action={<span className="text-xs text-muted-foreground">{year} · {SEASONS[seasonIndex].label}</span>}>
            <AntarcticMap layerId={layerId} year={year} seasonId={seasonId} selected={selected} onSelect={setSelected} />
          </Panel>

          <Panel title="Regional analysis" action={interpretation ? <SampleTag /> : null}>
            {!selected || !values || !interpretation ? (
              <p className="text-sm text-muted-foreground">
                Click a location on the map. The analysis shows observations, possible microbes, documented virus relationships, alternative causes and confidence.
              </p>
            ) : (
              <div className="space-y-5 text-sm">
                <div>
                  <p className="font-mono text-xs text-muted-foreground">
                    {selected.lat.toFixed(3)}° lat · {selected.lon.toFixed(3)}° lon · {latitudeBand(selected.lat)}
                  </p>
                </div>

                <div>
                  <h3 className="mb-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground">1. Environmental observations</h3>
                  <dl className="grid grid-cols-2 gap-x-4 gap-y-2">
                    {(Object.keys(values) as (keyof typeof values)[]).map((id) => {
                      const layer = LAYERS_BY_ID[id];
                      return (
                        <div key={id} className="flex flex-col">
                          <dt className="text-xs text-muted-foreground">{layer.label}</dt>
                          <dd className="tabular-nums" style={{ color: `hsl(var(--${layer.cssVar}))` }}>
                            {values[id].toFixed(2)} <span className="text-xs text-muted-foreground">{layer.unit}</span>
                          </dd>
                        </div>
                      );
                    })}
                  </dl>
                </div>

                <Block title="2. Possible microorganism groups" items={interpretation.microbes} />
                <Block title="3. Potential viral hosts" items={interpretation.hosts} />

                <div>
                  <h3 className="mb-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground">4. Documented virus groups</h3>
                  <ul className="space-y-2">
                    {interpretation.viruses.map((v) => (
                      <li key={v.virus} className="rounded-lg border border-border p-2.5">
                        <p className="font-medium">{v.virus}</p>
                        <p className="text-xs text-muted-foreground">{v.evidence}. {v.antarcticNote}</p>
                      </li>
                    ))}
                  </ul>
                </div>

                <Block title="5. Environmental conditions" items={interpretation.conditions} />
                <Block title="Alternative explanations" items={interpretation.alternatives} />

                <div>
                  <h3 className="mb-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground">6. Confidence and limitations</h3>
                  <p className="text-muted-foreground">{interpretation.confidence}</p>
                </div>
              </div>
            )}
          </Panel>
        </div>

        <TimeSeriesCard defaultVariable="chlorophyll" />
      </div>
    </div>
  );
}

function Block({ title, items }: { title: string; items: string[] }) {
  return (
    <div>
      <h3 className="mb-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground">{title}</h3>
      <ul className="list-inside list-disc space-y-1 text-muted-foreground">
        {items.map((item) => (
          <li key={item}>{item}</li>
        ))}
      </ul>
    </div>
  );
}
