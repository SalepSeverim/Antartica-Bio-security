import { PageHeader, Panel, SampleNotice } from "@/components/bioscan/parts";

const MISSIONS = [
  {
    mission: "NASA MODIS Aqua",
    variables: "Chlorophyll-a, ocean color, remote sensing reflectance (Rrs), normalized water-leaving radiance (nLw), sea surface temperature",
    provider: "NASA Ocean Color (OB.DAAC)",
    mapLayers: "Chlorophyll-a, ocean color, SST",
  },
  {
    mission: "NASA VIIRS",
    variables: "Chlorophyll-a, ocean color, Rrs, nLw, sea surface temperature",
    provider: "NASA Ocean Color (OB.DAAC)",
    mapLayers: "Chlorophyll-a, ocean color (MODIS vs VIIRS comparison planned)",
  },
  {
    mission: "NASA AIRS",
    variables: "Atmospheric temperature profiles and changes at pressure levels",
    provider: "NASA GES DISC",
    mapLayers: "Atmospheric temperature (kept separate from surface temperature)",
  },
  {
    mission: "NASA OMI (Aura)",
    variables: "Sulfur dioxide (SO₂), nitrogen dioxide (NO₂), atmospheric column density",
    provider: "NASA GES DISC",
    mapLayers: "SO₂ and NO₂ on separate layers",
  },
  {
    mission: "NASA NSIDC",
    variables: "Antarctic sea ice concentration, extent and seasonal change",
    provider: "National Snow and Ice Data Center",
    mapLayers: "Sea ice (NASA GIBS MODIS Terra sea ice overlay)",
  },
];

export default function SatelliteDataRoute() {
  return (
    <div className="flex min-h-full flex-col">
      <PageHeader title="NASA Satellite Data" subtitle="Missions, variables and connection status for each data layer." />
      <div className="space-y-5 p-6">
        <SampleNotice />
        <Panel title="Data missions">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px] text-left text-sm">
              <thead className="text-xs uppercase tracking-wider text-muted-foreground">
                <tr className="border-b border-border">
                  <th className="py-2 pr-4 font-medium">Mission</th>
                  <th className="py-2 pr-4 font-medium">Variables</th>
                  <th className="py-2 pr-4 font-medium">Provider</th>
                  <th className="py-2 pr-4 font-medium">Map display</th>
                  <th className="py-2 font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {MISSIONS.map((m) => (
                  <tr key={m.mission} className="border-b border-border/60 align-top">
                    <td className="py-3 pr-4 font-medium text-primary">{m.mission}</td>
                    <td className="py-3 pr-4 text-muted-foreground">{m.variables}</td>
                    <td className="py-3 pr-4 text-muted-foreground">{m.provider}</td>
                    <td className="py-3 pr-4 text-muted-foreground">{m.mapLayers}</td>
                    <td className="py-3 text-xs text-muted-foreground">Not connected</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>
        <Panel title="Connection">
          <p className="text-sm text-muted-foreground">
            The map base layer and sea ice overlay come from NASA GIBS imagery. Quantitative values from MODIS, VIIRS, AIRS and OMI are not connected yet, so they appear as labeled samples. Each live value will show its satellite, product name, observation date, units and source.
          </p>
        </Panel>
      </div>
    </div>
  );
}
