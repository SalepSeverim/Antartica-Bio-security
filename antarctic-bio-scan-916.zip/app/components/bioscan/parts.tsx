import { IconInfoCircle } from "@tabler/icons-react";

import { SAMPLE_NOTICE } from "@/lib/bioscan/data";
import { cn } from "@/lib/utils";

export function PageHeader({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle?: string;
  children?: React.ReactNode;
}) {
  return (
    <header className="flex flex-col gap-3 border-b border-border px-6 py-5 md:flex-row md:items-center md:justify-between">
      <div>
        <h1 className="text-xl font-semibold tracking-tight md:text-2xl">{title}</h1>
        {subtitle ? <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p> : null}
      </div>
      {children ? <div className="flex flex-wrap items-center gap-2">{children}</div> : null}
    </header>
  );
}

export function SampleNotice({ className }: { className?: string }) {
  return (
    <div
      className={cn(
        "flex items-start gap-2.5 rounded-lg border border-bio-atm/40 bg-bio-atm/10 px-3.5 py-2.5 text-xs text-foreground",
        className,
      )}
    >
      <IconInfoCircle size={16} className="mt-px shrink-0 text-bio-atm" />
      <p>{SAMPLE_NOTICE}</p>
    </div>
  );
}

export function SampleTag() {
  return (
    <span className="rounded-full border border-bio-atm/50 bg-bio-atm/10 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider text-bio-atm">
      Sample
    </span>
  );
}

export function Panel({
  title,
  action,
  children,
  className,
}: {
  title?: string;
  action?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section
      className={cn(
        "rounded-xl border border-border bg-card/80 p-4 shadow-[0_0_0_1px_hsl(190_100%_50%/0.04),0_8px_30px_-12px_hsl(190_100%_50%/0.15)] backdrop-blur",
        className,
      )}
    >
      {title || action ? (
        <div className="mb-3 flex items-center justify-between gap-3">
          {title ? <h2 className="text-sm font-semibold tracking-tight">{title}</h2> : <span />}
          {action}
        </div>
      ) : null}
      {children}
    </section>
  );
}

export function StatCard({
  label,
  value,
  unit,
  cssVar,
  icon,
  trend,
}: {
  label: string;
  value: string;
  unit: string;
  cssVar: string;
  icon: React.ReactNode;
  trend: string;
}) {
  return (
    <div
      className="relative overflow-hidden rounded-xl border bg-card/80 p-4"
      style={{ borderColor: `hsl(var(--${cssVar}) / 0.35)` }}
    >
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium text-muted-foreground">{label}</span>
        <span style={{ color: `hsl(var(--${cssVar}))` }}>{icon}</span>
      </div>
      <div className="mt-2 flex items-baseline gap-1.5">
        <span className="text-2xl font-semibold tabular-nums" style={{ color: `hsl(var(--${cssVar}))` }}>
          {value}
        </span>
        <span className="text-xs text-muted-foreground">{unit}</span>
      </div>
      <div className="mt-1 flex items-center justify-between">
        <span className="text-[11px] text-muted-foreground">{trend}</span>
        <SampleTag />
      </div>
    </div>
  );
}
