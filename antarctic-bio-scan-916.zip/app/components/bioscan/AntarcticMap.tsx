import { IconMinus, IconPlus, IconTarget } from "@tabler/icons-react";
import { useEffect, useMemo, useRef, useState } from "react";

import { Button } from "@/components/ui/button";
import {
  fieldColor,
  fieldWeight,
  LAYERS,
  LAYERS_BY_ID,
  SEASONS,
  sampleValue,
  type LayerId,
  type SeasonId,
} from "@/lib/bioscan/data";
import { gibsSnapshotUrl, lonLatToXY, pixelToXY, xyToLonLat, xyToPixel } from "@/lib/bioscan/polar";
import { cn } from "@/lib/utils";

const BASE_LAYER = "MODIS_Terra_CorrectedReflectance_TrueColor";
const IMAGE_SIZE = 1200;
const FIELD_SIZE = 160;

export interface SelectedPoint {
  lat: number;
  lon: number;
}

export function seasonMonth(seasonId: SeasonId) {
  return SEASONS.find((s) => s.id === seasonId)?.month ?? "01";
}

export function imageDate(year: number, seasonId: SeasonId) {
  return `${year}-${seasonMonth(seasonId)}-15`;
}

export function AntarcticMap({
  layerId,
  year,
  seasonId,
  selected,
  onSelect,
}: {
  layerId: LayerId;
  year: number;
  seasonId: SeasonId;
  selected: SelectedPoint | null;
  onSelect: (point: SelectedPoint) => void;
}) {
  const [zoom, setZoom] = useState(1);
  const [failedUrl, setFailedUrl] = useState<string | null>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const layer = LAYERS_BY_ID[layerId];
  const date = imageDate(year, seasonId);
  const baseUrl = gibsSnapshotUrl({ layer: BASE_LAYER, date, size: IMAGE_SIZE, format: "image/jpeg" });
  const overlayUrl = layer.gibsLayer
    ? gibsSnapshotUrl({ layer: layer.gibsLayer, date, size: IMAGE_SIZE, format: "image/png" })
    : null;
  const seasonIndex = SEASONS.findIndex((s) => s.id === seasonId);
  const baseFailed = failedUrl === baseUrl;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || layer.gibsLayer) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const image = ctx.createImageData(FIELD_SIZE, FIELD_SIZE);
    const [lo, hi] = layer.range;
    for (let j = 0; j < FIELD_SIZE; j++) {
      for (let i = 0; i < FIELD_SIZE; i++) {
        const { x, y } = pixelToXY(i + 0.5, j + 0.5, FIELD_SIZE);
        const { lat, lon } = xyToLonLat(x, y);
        const weight = fieldWeight(lat);
        const t = (sampleValue(layerId, lat, lon, year, seasonIndex) - lo) / (hi - lo);
        const [r, g, b] = fieldColor(layer, t);
        const idx = (j * FIELD_SIZE + i) * 4;
        image.data[idx] = r;
        image.data[idx + 1] = g;
        image.data[idx + 2] = b;
        image.data[idx + 3] = Math.round(190 * weight);
      }
    }
    ctx.putImageData(image, 0, 0);
  }, [layer, layerId, year, seasonIndex]);

  const marker = useMemo(() => {
    if (!selected) return null;
    const { x, y } = lonLatToXY(selected.lat, selected.lon);
    return xyToPixel(x, y);
  }, [selected]);

  const handleClick = (event: React.MouseEvent<HTMLDivElement>) => {
    const rect = wrapperRef.current?.getBoundingClientRect();
    if (!rect) return;
    const px = ((event.clientX - rect.left) / rect.width) * IMAGE_SIZE;
    const py = ((event.clientY - rect.top) / rect.height) * IMAGE_SIZE;
    const { x, y } = pixelToXY(px, py, IMAGE_SIZE);
    const { lat, lon } = xyToLonLat(x, y);
    onSelect({ lat: Number(lat.toFixed(3)), lon: Number(lon.toFixed(3)) });
  };

  return (
    <div className="flex flex-col gap-3">
      <div className="relative mx-auto aspect-square w-full max-w-[680px] overflow-hidden rounded-xl border border-border bg-[#02060f]">
        <div
          ref={wrapperRef}
          onClick={handleClick}
          className="absolute inset-0 cursor-crosshair transition-transform duration-200"
          style={{ transform: `scale(${zoom})` }}
        >
          {baseFailed ? (
            <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
              NASA imagery is unavailable for this date.
            </div>
          ) : (
            <img
              key={baseUrl}
              src={baseUrl}
              alt="NASA MODIS Terra true-color imagery of Antarctica"
              className="pointer-events-none absolute inset-0 h-full w-full select-none"
              draggable={false}
              onError={() => setFailedUrl(baseUrl)}
            />
          )}
          {overlayUrl ? (
            <img
              key={overlayUrl}
              src={overlayUrl}
              alt=""
              className="pointer-events-none absolute inset-0 h-full w-full opacity-85"
              draggable={false}
            />
          ) : (
            <canvas
              ref={canvasRef}
              width={FIELD_SIZE}
              height={FIELD_SIZE}
              className="pointer-events-none absolute inset-0 h-full w-full opacity-80 [image-rendering:auto]"
            />
          )}
          {marker ? (
            <div
              className="pointer-events-none absolute h-5 w-5 -translate-x-1/2 -translate-y-1/2"
              style={{ left: `${marker.px}%`, top: `${marker.py}%` }}
            >
              <div className="absolute inset-0 rounded-full border-2 border-primary shadow-[0_0_12px_hsl(var(--primary))]" />
              <div className="absolute left-1/2 top-1/2 h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary" />
            </div>
          ) : null}
        </div>

        <div className="absolute left-3 top-3 flex flex-col gap-1.5">
          <Button size="icon" variant="secondary" aria-label="Zoom in" onClick={() => setZoom((z) => Math.min(4, z + 0.5))}>
            <IconPlus size={16} />
          </Button>
          <Button size="icon" variant="secondary" aria-label="Zoom out" onClick={() => setZoom((z) => Math.max(1, z - 0.5))}>
            <IconMinus size={16} />
          </Button>
          <Button size="icon" variant="secondary" aria-label="Reset zoom" onClick={() => setZoom(1)}>
            <IconTarget size={16} />
          </Button>
        </div>

        <div className="pointer-events-none absolute bottom-3 left-3 rounded-md bg-background/80 px-2.5 py-1.5 font-mono text-[11px] text-foreground backdrop-blur">
          {selected
            ? `${selected.lat.toFixed(3)}° lat · ${selected.lon.toFixed(3)}° lon`
            : "Click the map to select a coordinate"}
        </div>
      </div>

      <div className="mx-auto flex w-full max-w-[680px] items-center gap-3 text-xs text-muted-foreground">
        <span className="font-medium text-foreground">{layer.label}</span>
        {layer.gibsLayer ? (
          <span>NASA GIBS · {layer.gibsLayer} · {layer.unit}</span>
        ) : (
          <>
            <span
              className="h-2.5 w-40 rounded-full"
              style={{
                background: `linear-gradient(to right, ${layer.ramp
                  .map((c) => `rgb(${c.join(",")})`)
                  .join(", ")})`,
              }}
            />
            <span>
              {layer.range[0]} – {layer.range[1]} {layer.unit} · sample field, not measured
            </span>
          </>
        )}
      </div>
      <div className="mx-auto hidden w-full max-w-[680px] flex-wrap gap-1.5 md:flex">
        {LAYERS.map((l) => (
          <span
            key={l.id}
            className={cn("rounded-full border px-2 py-0.5 text-[11px]", l.id === layerId ? "text-foreground" : "text-muted-foreground")}
            style={{ borderColor: `hsl(var(--${l.cssVar}) / ${l.id === layerId ? 0.8 : 0.3})` }}
          >
            {l.label}
          </span>
        ))}
      </div>
    </div>
  );
}
