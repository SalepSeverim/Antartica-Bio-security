import { useMemo, useState } from "react";

import { Button } from "@/components/ui/button";
import { getTimeSeries, TIME_SERIES_VARIABLES, type TimeSeriesVariable } from "@/lib/bioscan/data";
import { cn } from "@/lib/utils";

import { Panel, SampleTag } from "./parts";

const W = 720;
const H = 240;
const PAD = { l: 52, r: 12, t: 12, b: 28 };

function LineChart({
  labels,
  series,
  unit,
}: {
  labels: string[];
  series: { name: string; cssVar: string; values: number[] }[];
  unit: string;
}) {
  const all = series.flatMap((s) => s.values);
  const rawMin = Math.min(...all);
  const rawMax = Math.max(...all);
  const span = rawMax - rawMin || 1;
  const min = rawMin - span * 0.1;
  const max = rawMax + span * 0.1;
  const x = (i: number) => PAD.l + (i / Math.max(1, labels.length - 1)) * (W - PAD.l - PAD.r);
  const y = (v: number) => PAD.t + (1 - (v - min) / (max - min)) * (H - PAD.t - PAD.b);
  const ticks = [0, 1, 2, 3].map((i) => min + ((max - min) * i) / 3);
  const labelEvery = Math.ceil(labels.length / 8);

  return (
    <div className="space-y-2">
      <div className="flex flex-wrap gap-4 text-xs">
        {series.map((s) => (
          <span key={s.name} className="flex items-center gap-1.5 text-muted-foreground">
            <span className="h-0.5 w-4 rounded" style={{ background: `hsl(var(--${s.cssVar}))` }} />
            {s.name} ({unit})
          </span>
        ))}
      </div>
      <svg viewBox={`0 0 ${W} ${H}`} className="h-auto w-full" role="img" aria-label="Time series chart">
        {ticks.map((t) => (
          <g key={t}>
            <line x1={PAD.l} x2={W - PAD.r} y1={y(t)} y2={y(t)} stroke="hsl(var(--border))" strokeDasharray="3 4" />
            <text x={PAD.l - 8} y={y(t) + 4} textAnchor="end" className="fill-muted-foreground text-[11px]">
              {t.toFixed(span < 5 ? 2 : 0)}
            </text>
          </g>
        ))}
        {labels.map((l, i) =>
          i % labelEvery === 0 ? (
            <text key={l} x={x(i)} y={H - 8} textAnchor="middle" className="fill-muted-foreground text-[11px]">
              {l}
            </text>
          ) : null,
        )}
        {series.map((s) => (
          <path
            key={s.name}
            d={s.values.map((v, i) => `${i === 0 ? "M" : "L"}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(" ")}
            fill="none"
            stroke={`hsl(var(--${s.cssVar}))`}
            strokeWidth={2}
            strokeLinejoin="round"
          />
        ))}
      </svg>
    </div>
  );
}

export function TimeSeriesCard({ defaultVariable = "chlorophyll" }: { defaultVariable?: TimeSeriesVariable["id"] }) {
  const [variableId, setVariableId] = useState<TimeSeriesVariable["id"]>(defaultVariable);
  const [interval, setInterval] = useState<"monthly" | "yearly">("monthly");
  const variable = TIME_SERIES_VARIABLES.find((v) => v.id === variableId) ?? TIME_SERIES_VARIABLES[0];
  const data = useMemo(() => getTimeSeries(variable, interval), [variable, interval]);

  return (
    <Panel
      title="Time series analysis"
      action={
        <div className="flex items-center gap-2">
          <div className="flex rounded-lg border border-border p-0.5">
            {(["monthly", "yearly"] as const).map((i) => (
              <button
                key={i}
                type="button"
                onClick={() => setInterval(i)}
                className={cn(
                  "rounded-md px-2.5 py-1 text-xs capitalize transition-colors",
                  interval === i ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground",
                )}
              >
                {i}
              </button>
            ))}
          </div>
          <SampleTag />
        </div>
      }
    >
      <div className="mb-4 flex flex-wrap gap-1.5">
        {TIME_SERIES_VARIABLES.map((v) => (
          <Button
            key={v.id}
            size="sm"
            variant={variableId === v.id ? "default" : "outline"}
            onClick={() => setVariableId(v.id)}
          >
            {v.label}
          </Button>
        ))}
      </div>
      <LineChart labels={data.labels} series={data.series} unit={variable.unit} />
    </Panel>
  );
}
