import { AgentSidebar } from "@agent-native/toolkit/app/chat";
import { HeaderActionsProvider } from "@agent-native/toolkit/app-shell";
import {
  IconDatabase,
  IconFileAnalytics,
  IconHome,
  IconListSearch,
  IconMap2,
  IconSatellite,
  IconVirus,
  IconWind,
} from "@tabler/icons-react";
import { NavLink } from "react-router";

import { TAB_ID } from "@/lib/tab-id";
import { cn } from "@/lib/utils";

interface LayoutProps {
  children: React.ReactNode;
}

const NAV = [
  { to: "/", label: "Home Dashboard", icon: IconHome },
  { to: "/map", label: "Antarctic Map", icon: IconMap2 },
  { to: "/satellite-data", label: "NASA Satellite Data", icon: IconSatellite },
  { to: "/virus-analysis", label: "Virus & Microbe Analysis", icon: IconVirus },
  { to: "/dms-sulfur", label: "DMS & Sulfur Cycle", icon: IconWind },
  { to: "/alternative-causes", label: "Alternative Causes", icon: IconListSearch },
  { to: "/reports", label: "Analysis Reports", icon: IconFileAnalytics },
  { to: "/data-sources", label: "Data Sources & Methods", icon: IconDatabase },
];

const NASA_SOURCES = [
  { name: "MODIS Aqua", detail: "Chlorophyll-a, ocean color, SST" },
  { name: "VIIRS", detail: "Chlorophyll-a, ocean color" },
  { name: "AIRS", detail: "Atmospheric temperature" },
  { name: "OMI (Aura)", detail: "SO₂, NO₂" },
  { name: "NSIDC", detail: "Sea ice extent" },
];

export function Layout({ children }: LayoutProps) {
  return (
    <HeaderActionsProvider>
      <AgentSidebar
        position="right"
        storageKey="bioscan-agent"
        browserTabId={TAB_ID}
        defaultOpen={false}
        emptyStateText="Ask about Antarctic satellite data, documented virus-host relationships, or DMS sources."
      >
        <div className="flex h-screen w-full flex-col overflow-hidden bg-background text-foreground md:flex-row">
          <aside className="flex shrink-0 flex-col border-b border-sidebar-border bg-sidebar-background md:w-60 md:border-b-0 md:border-r">
            <div className="flex items-center gap-3 px-5 py-4">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/15 text-primary ring-1 ring-primary/40">
                <IconVirus size={20} />
              </div>
              <div>
                <p className="text-sm font-semibold tracking-tight">Antarctic Bio-Scan</p>
                <p className="text-[11px] text-sidebar-foreground">Satellite microbe monitoring</p>
              </div>
            </div>
            <nav className="flex gap-1 overflow-x-auto px-3 pb-3 md:flex-col md:overflow-visible md:pb-0">
              {NAV.map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  end={item.to === "/"}
                  className={({ isActive }) =>
                    cn(
                      "flex shrink-0 items-center gap-2.5 rounded-lg px-3 py-2 text-sm transition-colors",
                      isActive
                        ? "bg-sidebar-accent text-sidebar-accent-foreground ring-1 ring-primary/30"
                        : "text-sidebar-foreground hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground",
                    )
                  }
                >
                  <item.icon size={17} />
                  {item.label}
                </NavLink>
              ))}
            </nav>
            <div className="mt-auto hidden px-5 pb-5 pt-6 md:block">
              <p className="mb-2 text-[11px] font-medium uppercase tracking-widest text-sidebar-foreground">
                NASA data used
              </p>
              <ul className="space-y-2">
                {NASA_SOURCES.map((s) => (
                  <li key={s.name} className="text-xs">
                    <span className="font-medium text-sidebar-accent-foreground">{s.name}</span>
                    <span className="block text-[11px] text-sidebar-foreground">{s.detail}</span>
                  </li>
                ))}
              </ul>
            </div>
          </aside>
          <main className="agent-native-app-main min-w-0 flex-1 overflow-y-auto overscroll-contain">
            {children}
          </main>
        </div>
      </AgentSidebar>
    </HeaderActionsProvider>
  );
}
