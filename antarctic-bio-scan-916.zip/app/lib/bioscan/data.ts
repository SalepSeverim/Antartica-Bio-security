export const SAMPLE_NOTICE =
  "Sample values are for layout and interpretation logic only. Live NASA observations are not connected yet, so none of the numbers below are satellite measurements.";

export const YEARS = [2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025] as const;

export const SEASONS = [
  { id: "summer", label: "Summer", month: "01" },
  { id: "autumn", label: "Autumn", month: "03" },
  { id: "winter", label: "Winter", month: "08" },
  { id: "spring", label: "Spring", month: "10" },
] as const;

export type SeasonId = (typeof SEASONS)[number]["id"];
export type Rgb = [number, number, number];

export type LayerId =
  | "chlorophyll"
  | "oceanColor"
  | "sst"
  | "atmTemp"
  | "so2"
  | "no2"
  | "seaIce";

export interface LayerDef {
  id: LayerId;
  label: string;
  unit: string;
  instrument: string;
  product: string;
  cssVar: string;
  ramp: Rgb[];
  range: [number, number];
  seed: number;
  gibsLayer?: string;
}

export const LAYERS: LayerDef[] = [
  {
    id: "chlorophyll",
    label: "Chlorophyll-a",
    unit: "mg/m³",
    instrument: "MODIS Aqua, VIIRS",
    product: "Level-3 chlorophyll-a",
    cssVar: "bio-chlorophyll",
    ramp: [[30, 40, 140], [0, 170, 200], [60, 230, 120], [255, 230, 60], [255, 70, 40]],
    range: [0.1, 5],
    seed: 1.3,
  },
  {
    id: "oceanColor",
    label: "Ocean color (nLw)",
    unit: "mW cm⁻² µm⁻¹ sr⁻¹",
    instrument: "MODIS Aqua, VIIRS",
    product: "Normalized water-leaving radiance",
    cssVar: "bio-ocean",
    ramp: [[20, 30, 90], [20, 110, 190], [60, 220, 240]],
    range: [0, 2],
    seed: 2.1,
  },
  {
    id: "sst",
    label: "Sea surface temp",
    unit: "°C",
    instrument: "MODIS Aqua",
    product: "Level-3 sea surface temperature",
    cssVar: "bio-sst",
    ramp: [[60, 40, 160], [40, 120, 230], [120, 220, 255]],
    range: [-2, 1],
    seed: 3.7,
  },
  {
    id: "atmTemp",
    label: "Atmospheric temp",
    unit: "K",
    instrument: "AIRS",
    product: "Air temperature at pressure level",
    cssVar: "bio-atm",
    ramp: [[90, 60, 150], [240, 160, 60], [255, 240, 150]],
    range: [215, 250],
    seed: 4.9,
  },
  {
    id: "so2",
    label: "SO₂ column",
    unit: "DU",
    instrument: "OMI (Aura)",
    product: "Sulfur dioxide total column",
    cssVar: "bio-so2",
    ramp: [[50, 30, 110], [150, 80, 220], [230, 170, 255]],
    range: [0, 0.6],
    seed: 5.2,
  },
  {
    id: "no2",
    label: "NO₂ column",
    unit: "10¹⁵ molec/cm²",
    instrument: "OMI (Aura)",
    product: "Nitrogen dioxide tropospheric column",
    cssVar: "bio-no2",
    ramp: [[90, 40, 20], [240, 120, 40], [255, 210, 120]],
    range: [0, 0.5],
    seed: 6.4,
  },
  {
    id: "seaIce",
    label: "Sea ice",
    unit: "%",
    instrument: "MODIS Terra / NSIDC",
    product: "Sea ice cover",
    cssVar: "bio-ice",
    ramp: [],
    range: [0, 100],
    seed: 0,
    gibsLayer: "MODIS_Terra_Sea_Ice",
  },
];

export const LAYERS_BY_ID = Object.fromEntries(LAYERS.map((l) => [l.id, l])) as Record<LayerId, LayerDef>;

const ring = (lat: number) => {
  const d = (lat + 70) / 7;
  return Math.exp(-d * d);
};

export function sampleValue(id: LayerId, lat: number, lon: number, year: number, seasonIndex: number) {
  const layer = LAYERS_BY_ID[id];
  const r = Math.PI / 180;
  const phase = layer.seed + (year - 2018) * 0.35 + seasonIndex * 1.1;
  const shape =
    0.5 +
    0.22 * Math.sin(2 * lon * r + phase) * Math.cos(3 * lat * r + phase * 0.7) +
    0.18 * Math.sin(5 * lon * r - phase);
  const normalized = Math.min(1, Math.max(0, shape));
  const [lo, hi] = layer.range;
  return lo + normalized * (hi - lo) * (0.4 + 0.6 * ring(lat));
}

export function fieldColor(layer: LayerDef, t: number): Rgb {
  const stops = layer.ramp;
  const scaled = Math.min(0.999, Math.max(0, t)) * (stops.length - 1);
  const i = Math.floor(scaled);
  const f = scaled - i;
  const a = stops[i];
  const b = stops[i + 1];
  return [0, 1, 2].map((k) => a[k] + (b[k] - a[k]) * f) as Rgb;
}

export function fieldWeight(lat: number) {
  return ring(lat);
}

export interface TimeSeriesVariable {
  id: "chlorophyll" | "temperature" | "seaIce" | "so2" | "no2";
  label: string;
  unit: string;
  series: { name: string; cssVar: string; base: number; amp: number; trend: number; phase: number; seed: number }[];
}

export const TIME_SERIES_VARIABLES: TimeSeriesVariable[] = [
  {
    id: "chlorophyll",
    label: "Chlorophyll-a",
    unit: "mg/m³",
    series: [{ name: "Chlorophyll-a", cssVar: "bio-chlorophyll", base: 1.8, amp: 0.9, trend: 0.03, phase: 0, seed: 1 }],
  },
  {
    id: "temperature",
    label: "Sea surface temp",
    unit: "°C",
    series: [{ name: "SST", cssVar: "bio-sst", base: -1.4, amp: 0.8, trend: 0.02, phase: Math.PI, seed: 2 }],
  },
  {
    id: "seaIce",
    label: "Sea ice",
    unit: "%",
    series: [{ name: "Sea ice", cssVar: "bio-ice", base: 65, amp: 22, trend: -0.4, phase: Math.PI, seed: 3 }],
  },
  {
    id: "so2",
    label: "SO₂",
    unit: "DU",
    series: [{ name: "SO₂", cssVar: "bio-so2", base: 0.16, amp: 0.05, trend: 0.002, phase: 0.5, seed: 4 }],
  },
  {
    id: "no2",
    label: "NO₂",
    unit: "10¹⁵ molec/cm²",
    series: [{ name: "NO₂", cssVar: "bio-no2", base: 0.25, amp: 0.06, trend: 0.001, phase: 1, seed: 5 }],
  },
];

const MONTHS = YEARS.flatMap((y) => Array.from({ length: 12 }, (_, m) => ({ year: y, month: m })));

export function getTimeSeries(variable: TimeSeriesVariable, interval: "monthly" | "yearly") {
  const monthlyLabels = MONTHS.map((m) => `${m.year}-${String(m.month + 1).padStart(2, "0")}`);
  const series = variable.series.map((s) => {
    const monthly = MONTHS.map((m, i) => {
      const season = (2 * Math.PI * m.month) / 12 + s.phase;
      const noise = 0.08 * s.amp * Math.sin(i * 1.7 + s.seed);
      return s.base + s.amp * Math.sin(season) + s.trend * i + noise;
    });
    if (interval === "monthly") return { name: s.name, cssVar: s.cssVar, values: monthly };
    const values = YEARS.map((y) => {
      const slice = monthly.filter((_, i) => MONTHS[i].year === y);
      return slice.reduce((a, b) => a + b, 0) / slice.length;
    });
    return { name: s.name, cssVar: s.cssVar, values };
  });
  return {
    labels: interval === "monthly" ? monthlyLabels : YEARS.map(String),
    series,
  };
}

export interface VirusRelation {
  virus: string;
  family: string;
  host: string;
  evidence: "Cultured and characterized" | "Environmental detection reported" | "Potential relationship (inferred)";
  antarcticNote: string;
}

export const VIRUS_CATALOG: VirusRelation[] = [
  {
    virus: "Phaeocystis globosa virus (PgV)",
    family: "Phycodnaviridae (large dsDNA algal viruses)",
    host: "Phaeocystis globosa",
    evidence: "Cultured and characterized",
    antarcticNote: "Infects a close relative of Phaeocystis antarctica. Infection of P. antarctica itself is not established.",
  },
  {
    virus: "Phaeocystis pouchetii virus (PpV)",
    family: "Phycodnaviridae",
    host: "Phaeocystis pouchetii",
    evidence: "Cultured and characterized",
    antarcticNote: "Characterized from temperate and Arctic-associated blooms. No Antarctic-specific isolate is listed here.",
  },
  {
    virus: "Diatom-infecting RNA viruses (e.g., Rhizosolenia setigera RNA virus)",
    family: "Bacillarnaviridae",
    host: "Marine diatoms (e.g., Rhizosolenia)",
    evidence: "Environmental detection reported",
    antarcticNote: "Reported in marine diatom bloom studies. Antarctic-specific host-virus pairs need verification.",
  },
  {
    virus: "Bacteriophages infecting marine bacteria (e.g., Pseudoalteromonas phages)",
    family: "Various (bacteriophages)",
    host: "Heterotrophic marine bacteria",
    evidence: "Potential relationship (inferred)",
    antarcticNote: "Phages from Antarctic waters have been isolated in culture. Host range must be confirmed per isolate.",
  },
];

export interface LocationInterpretation {
  microbes: string[];
  hosts: string[];
  viruses: VirusRelation[];
  conditions: string[];
  alternatives: string[];
  confidence: string;
}

export function interpretLocation(values: {
  chlorophyll: number;
  seaIce: number;
  so2: number;
  no2: number;
}): LocationInterpretation {
  const bloom = values.chlorophyll >= 2;
  const microbes = bloom
    ? ["Phytoplankton growth signal (chlorophyll-a elevated in sample)", "Heterotrophic bacteria following bloom"]
    : ["Low phytoplankton signal; satellites do not resolve bacteria or viruses"];
  const hosts = bloom ? ["Phaeocystis antarctica", "Diatoms"] : ["No phytoplankton host triggered by this signal"];
  const conditions = [
    values.seaIce > 15
      ? "Sea ice cover present: ice-associated microbial habitat may be relevant"
      : "Open water or thin ice: sea-ice habitat unlikely at this point",
    bloom ? "Elevated chlorophyll-a: candidate for targeted field sampling" : "No bloom-scale chlorophyll in the sample",
  ];
  const alternatives = [
    "Nutrient availability or zooplankton grazing can also change chlorophyll-a",
    values.so2 > 0.3 ? "Elevated SO₂: volcanic emissions or atmospheric transport are more likely than viral activity" : "SO₂ sample is low: no volcanic signal indicated",
    values.no2 > 0.3 ? "Elevated NO₂: atmospheric transport or combustion; no viral attribution" : "NO₂ sample is low",
  ];
  return {
    microbes,
    hosts,
    viruses: VIRUS_CATALOG,
    conditions,
    alternatives,
    confidence:
      "Low. Based on sample values and the documented host-virus catalog. Cloud cover, polar night and sea-ice interference are not yet accounted for.",
  };
}

export const LIMITATIONS = [
  "Ocean color and chlorophyll-a need sunlight and open water. They are unavailable during polar night and often under sea ice.",
  "Clouds block optical sensors, so gaps in daily data are expected.",
  "AIRS measures atmospheric temperature, not sea surface or surface air temperature at ground level.",
  "OMI SO₂ and NO₂ are column measurements at coarse pixel sizes. They do not identify the source of the gas.",
  "No NASA instrument in this platform measures dimethyl sulfide (DMS) directly.",
  "Satellite observations cannot detect viruses. Virus information comes only from published studies.",
];
