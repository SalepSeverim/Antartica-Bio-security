const A = 6378137;
const E = 0.0818191908426215;
const LAT_TS = 71;
const deg = Math.PI / 180;

export const POLAR_EXTENT = 4194304;

const toT = (phi: number) =>
  Math.tan(Math.PI / 4 - phi / 2) /
  Math.pow((1 - E * Math.sin(phi)) / (1 + E * Math.sin(phi)), E / 2);

const MC = Math.cos(LAT_TS * deg) / Math.sqrt(1 - E * E * Math.sin(LAT_TS * deg) ** 2);
const RHO_SCALE = (A * MC) / toT(LAT_TS * deg);

export function lonLatToXY(lat: number, lon: number) {
  const rho = RHO_SCALE * toT(-lat * deg);
  return { x: rho * Math.sin(lon * deg), y: rho * Math.cos(lon * deg) };
}

export function xyToLonLat(x: number, y: number) {
  const t = Math.hypot(x, y) / RHO_SCALE;
  let phi = Math.PI / 2 - 2 * Math.atan(t);
  for (let i = 0; i < 6; i++) {
    const s = Math.sin(phi);
    phi = Math.PI / 2 - 2 * Math.atan(t * Math.pow((1 - E * s) / (1 + E * s), E / 2));
  }
  return { lat: -phi / deg, lon: Math.atan2(x, y) / deg };
}

export function pixelToXY(px: number, py: number, size: number) {
  return {
    x: -POLAR_EXTENT + (px / size) * 2 * POLAR_EXTENT,
    y: POLAR_EXTENT - (py / size) * 2 * POLAR_EXTENT,
  };
}

export function xyToPixel(x: number, y: number) {
  return {
    px: ((x + POLAR_EXTENT) / (2 * POLAR_EXTENT)) * 100,
    py: ((POLAR_EXTENT - y) / (2 * POLAR_EXTENT)) * 100,
  };
}

export function gibsSnapshotUrl(options: {
  layer: string;
  date: string;
  size: number;
  format: "image/jpeg" | "image/png";
}) {
  const params = new URLSearchParams({
    REQUEST: "GetSnapshot",
    TIME: `${options.date}T00:00:00Z`,
    BBOX: `-${POLAR_EXTENT},-${POLAR_EXTENT},${POLAR_EXTENT},${POLAR_EXTENT}`,
    CRS: "EPSG:3031",
    LAYERS: options.layer,
    FORMAT: options.format,
    TRANSPARENT: "TRUE",
    WIDTH: String(options.size),
    HEIGHT: String(options.size),
  });
  return `https://wvs.earthdata.nasa.gov/api/v1/snapshot?${params.toString()}`;
}
